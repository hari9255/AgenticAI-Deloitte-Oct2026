"""Personal Agent (A2A CLIENT / host agent) built with LangGraph.

It does NOT know how to book hotels or cars itself. Instead it:
  1. DISCOVERS remote agents by downloading their Agent Cards
  2. lets the LLM decide which remote agent should handle the request
  3. COMMUNICATES with that agent over A2A (JSON-RPC over HTTP)

Run (after starting hotel_agent.py and car_rental_agent.py):
    python personal_agent.py
"""

import asyncio
import os

import httpx
from langchain.agents import create_agent
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver

from a2a.client import (
    A2ACardResolver,
    Client,
    ClientCallContext,
    ClientConfig,
    create_client,
)
from a2a.helpers import get_stream_response_text, new_text_message
from a2a.types import AgentCard, Role, SendMessageRequest, TaskState
from common import get_llm

REMOTE_AGENT_URLS = os.getenv(
    "REMOTE_AGENT_URLS", "http://localhost:10001,http://localhost:10002"
).split(",")
A2A_REQUEST_TIMEOUT_SECONDS = float(os.getenv("A2A_REQUEST_TIMEOUT_SECONDS", "120"))


class RemoteAgentRegistry:
    """Holds the Agent Cards, A2A clients and conversation ids of remote agents."""

    def __init__(self) -> None:
        self.cards: dict[str, AgentCard] = {}
        self.clients: dict[str, Client] = {}
        self.context_ids: dict[str, str] = {}  # keeps multi-turn conversations

    async def discover(self, urls: list[str]) -> None:
        """Step 1 - DISCOVERY: GET <url>/.well-known/agent-card.json"""
        async with httpx.AsyncClient(timeout=10) as http:
            for url in urls:
                card = await A2ACardResolver(httpx_client=http, base_url=url).get_agent_card()
                self.cards[card.name] = card
                self.clients[card.name] = await create_client(
                    agent=card, client_config=ClientConfig(streaming=False)
                )
                print(f"  discovered: {card.name:<18} @ {url}  skills={[s.name for s in card.skills]}")

    def describe(self) -> str:
        lines = []
        for name, card in self.cards.items():
            skills = "; ".join(f"{s.name}: {s.description}" for s in card.skills)
            lines.append(f"- {name}: {card.description} Skills: {skills}")
        return "\n".join(lines)

    async def send(self, agent_name: str, text: str) -> str:
        """Step 2/3 - COMMUNICATION: send an A2A Message, receive Task + Artifact."""
        if agent_name not in self.clients:
            return f"Unknown agent '{agent_name}'. Available: {list(self.clients)}"

        message = new_text_message(
            text,
            role=Role.ROLE_USER,
            context_id=self.context_ids.get(agent_name),  # continue same conversation
        )
        print(f"    [A2A ->] {agent_name}: {text}")

        reply = ""
        async for response in self.clients[agent_name].send_message(
            SendMessageRequest(message=message),
            context=ClientCallContext(timeout=A2A_REQUEST_TIMEOUT_SECONDS),
        ):
            if response.HasField("task"):
                task = response.task
                self.context_ids[agent_name] = task.context_id
                print(f"    [A2A <-] task {task.id[:8]} state={TaskState.Name(task.status.state)}")
            reply = get_stream_response_text(response) or reply
        print(f"    [A2A <-] {agent_name}: {reply}")
        return reply

    async def close(self) -> None:
        for c in self.clients.values():
            await c.close()


async def main() -> None:
    print("Discovering remote agents ...")
    registry = RemoteAgentRegistry()
    await registry.discover(REMOTE_AGENT_URLS)

    # ---- Tools that wrap the A2A protocol, so the LLM can delegate tasks ----
    @tool
    def list_remote_agents() -> str:
        """List the remote agents you can delegate work to, with their skills."""
        return registry.describe()

    @tool
    async def send_message(agent_name: str, task: str) -> str:
        """Send a task to a remote agent over the A2A protocol and return its answer.
        agent_name must be one of the names from list_remote_agents.
        Write the task as a complete, self-contained request."""
        return await registry.send(agent_name, task)

    personal_agent = create_agent(
        model=get_llm(),
        tools=[list_remote_agents, send_message],
        system_prompt=(
            "You are a personal travel assistant. You cannot book anything yourself. "
            "Delegate hotel work to 'Hotel Agent' and car work to 'Car Rental Agent' "
            "using send_message. You may call several agents for one request. "
            "Then give the user one combined, short answer.\n\n"
            f"Available agents:\n{registry.describe()}"
        ),
        checkpointer=InMemorySaver(),
    )

    config = {"configurable": {"thread_id": "user-session-1"}}
    print("\nPersonal Agent ready. Try: 'Plan a Goa trip from 2026-12-20 for 3 nights: "
          "cheapest hotel and an SUV'.  Type 'exit' to quit.\n")
    try:
        while True:
            user = (await asyncio.to_thread(input, "you > ")).strip()
            if user.lower() in {"exit", "quit", ""}:
                break
            result = await personal_agent.ainvoke({"messages": [("user", user)]}, config)
            print(f"\nassistant > {result['messages'][-1].text}\n")
    finally:
        await registry.close()


if __name__ == "__main__":
    asyncio.run(main())
