# A2A + LangGraph demo: Personal Agent → Hotel Agent + Car Rental Agent

```
             (A2A client)                         (A2A servers)
 user ──> Personal Agent  ── JSON-RPC/HTTP ──>  Hotel Agent       :10001  (LangGraph + tools)
          (LangGraph)     ── JSON-RPC/HTTP ──>  Car Rental Agent  :10002  (LangGraph + tools)
```

| A2A concept | Where in the code |
|---|---|
| Agent Card (discovery) | `build_agent_card()` in `common.py`, served at `/.well-known/agent-card.json` |
| Agent Executor | `LangGraphAgentExecutor` in `common.py` |
| Task lifecycle (submitted → working → completed) | `TaskUpdater` calls in `execute()` |
| Artifact (the result) | `updater.add_artifact(...)` |
| Message / contextId (multi-turn) | `RemoteAgentRegistry.send()` in `personal_agent.py` |

## Run
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # add your API key

python hotel_agent.py        # terminal 1
python car_rental_agent.py   # terminal 2
python personal_agent.py     # terminal 3  -> chat with it
```

See the raw protocol (no LLM on the client side):
```bash
python simple_client.py http://localhost:10001 "Find hotels in Goa"
```
