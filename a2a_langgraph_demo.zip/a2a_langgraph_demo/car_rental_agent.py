"""Car Rental Agent  — a LangGraph ReAct agent exposed as an A2A server.

Run:  python car_rental_agent.py      ->  http://localhost:10002
"""

from langchain.agents import create_agent
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver

from a2a.types import AgentSkill
from common import LangGraphAgentExecutor, build_agent_card, get_llm, serve

HOST, PORT = "localhost", 10002

# ---------------- Mock data / tools (replace with a real API) ----------------
CARS = [
    {"model": "Maruti Swift", "type": "hatchback", "price_per_day": 1800},
    {"model": "Hyundai Creta", "type": "suv", "price_per_day": 3200},
    {"model": "Toyota Innova Crysta", "type": "mpv", "price_per_day": 4500},
]
RENTALS: list[dict] = []


@tool
def search_cars(city: str, car_type: str = "any") -> list[dict]:
    """List rental cars available in a city. car_type: hatchback, suv, mpv or any.
    Prices are in INR per day."""
    if car_type == "any":
        return CARS
    return [c for c in CARS if c["type"] == car_type.lower()]


@tool
def book_car(car_model: str, city: str, pickup_date: str, days: int) -> dict:
    """Book a rental car. pickup_date is a date like 2026-12-20."""
    rental = {
        "rental_id": f"CAR-{len(RENTALS) + 1:04d}",
        "car": car_model,
        "city": city,
        "pickup_date": pickup_date,
        "days": days,
        "status": "CONFIRMED",
    }
    RENTALS.append(rental)
    return rental


# ---------------- LangGraph agent ----------------
graph = create_agent(
    model=get_llm(),
    tools=[search_cars, book_car],
    system_prompt=(
        "You are a car rental agent. Use the tools to find and book rental cars. "
        "If the city, pickup date or number of days is missing for a booking, ask "
        "for it. Keep answers short and include prices in INR."
    ),
    checkpointer=InMemorySaver(),
)

# ---------------- Agent Card ----------------
card = build_agent_card(
    name="Car Rental Agent",
    description="Finds and books rental cars in Indian cities.",
    url=f"http://{HOST}:{PORT}",
    skills=[
        AgentSkill(
            id="car_rental",
            name="Car search & booking",
            description="Find rental cars by type and book one.",
            tags=["travel", "car"],
            examples=["Show SUVs in Goa", "Book a Creta in Goa from 2026-12-20 for 3 days"],
        )
    ],
)

if __name__ == "__main__":
    serve(card, LangGraphAgentExecutor(graph, "Car Rental Agent"), HOST, PORT)
