"""Hotel Agent  — a LangGraph ReAct agent exposed as an A2A server.

Run:  python hotel_agent.py      ->  http://localhost:10001
"""

from langchain.agents import create_agent
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver

from a2a.types import AgentSkill
from common import LangGraphAgentExecutor, build_agent_card, get_llm, serve

HOST, PORT = "localhost", 10001

# ---------------- Mock data / tools (replace with a real API) ----------------
HOTELS = {
    "delhi": [
        {"name": "The Imperial", "price_per_night": 18000, "rating": 4.8},
        {"name": "Bloomrooms @ Link Road", "price_per_night": 4500, "rating": 4.2},
    ],
    "goa": [
        {"name": "Taj Fort Aguada", "price_per_night": 22000, "rating": 4.7},
        {"name": "Zostel Goa", "price_per_night": 1200, "rating": 4.3},
    ],
    "bengaluru": [
        {"name": "The Leela Palace", "price_per_night": 16000, "rating": 4.8},
        {"name": "Treebo Trend", "price_per_night": 3200, "rating": 4.0},
    ],
}
BOOKINGS: list[dict] = []


@tool
def search_hotels(city: str) -> list[dict]:
    """Search available hotels in a city. Prices are in INR per night."""
    return HOTELS.get(city.lower(), [])


@tool
def book_hotel(hotel_name: str, city: str, check_in: str, nights: int) -> dict:
    """Book a hotel. check_in is a date like 2026-12-20."""
    booking = {
        "booking_id": f"HTL-{len(BOOKINGS) + 1:04d}",
        "hotel": hotel_name,
        "city": city,
        "check_in": check_in,
        "nights": nights,
        "status": "CONFIRMED",
    }
    BOOKINGS.append(booking)
    return booking


# ---------------- LangGraph agent ----------------
graph = create_agent(
    model=get_llm(),
    tools=[search_hotels, book_hotel],
    system_prompt=(
        "You are a hotel booking agent. Use the tools to search and book hotels. "
        "If the city, check-in date or number of nights is missing for a booking, "
        "ask for it. Keep answers short and include prices in INR."
    ),
    checkpointer=InMemorySaver(),  # memory per A2A contextId
)

# ---------------- Agent Card (what can it do?) ----------------
card = build_agent_card(
    name="Hotel Agent",
    description="Searches and books hotels in Indian cities.",
    url=f"http://{HOST}:{PORT}",
    skills=[
        AgentSkill(
            id="hotel_booking",
            name="Hotel search & booking",
            description="Find hotels in a city and book a room.",
            tags=["travel", "hotel"],
            examples=["Find hotels in Goa", "Book Zostel Goa from 2026-12-20 for 3 nights"],
        )
    ],
)

if __name__ == "__main__":
    serve(card, LangGraphAgentExecutor(graph, "Hotel Agent"), HOST, PORT)
