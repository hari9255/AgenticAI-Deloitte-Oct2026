"""Bare-bones A2A client (no LLM) — shows the raw protocol steps.

    python simple_client.py http://localhost:10001 "Find hotels in Goa"

Prints:
  1. the Agent Card fetched from /.well-known/agent-card.json   (Discovery)
  2. every streamed event: Task, status updates, Artifact       (Communication)
"""

import asyncio
import sys

import httpx
from google.protobuf.json_format import MessageToJson

from a2a.client import A2ACardResolver, ClientConfig, create_client
from a2a.helpers import get_artifact_text, get_message_text, new_text_message
from a2a.types import Role, SendMessageRequest, TaskState


async def main(url: str, text: str) -> None:
    # ---- 1. Discovery ----
    async with httpx.AsyncClient() as http:
        card = await A2ACardResolver(httpx_client=http, base_url=url).get_agent_card()
    print("=== Agent Card ===")
    print(MessageToJson(card))

    # ---- 2. Communication (streaming over SSE) ----
    client = await create_client(agent=card, client_config=ClientConfig(streaming=True))
    request = SendMessageRequest(message=new_text_message(text, role=Role.ROLE_USER))

    print(f"\n=== Sending: {text!r} ===")
    async for event in client.send_message(request):
        if event.HasField("task"):
            t = event.task
            print(f"[Task]          id={t.id[:8]} context={t.context_id[:8]} "
                  f"state={TaskState.Name(t.status.state)}")
        elif event.HasField("status_update"):
            s = event.status_update.status
            note = get_message_text(s.message) if s.HasField("message") else ""
            print(f"[Status]        {TaskState.Name(s.state):<22} {note}")
        elif event.HasField("artifact_update"):
            a = event.artifact_update.artifact
            print(f"[Artifact]      {a.name}:\n{get_artifact_text(a)}")
        elif event.HasField("message"):
            print(f"[Message]       {get_message_text(event.message)}")
    await client.close()


if __name__ == "__main__":
    agent_url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:10001"
    query = sys.argv[2] if len(sys.argv) > 2 else "Find hotels in Goa"
    asyncio.run(main(agent_url, query))
