---
name: regime-comparison
description: >-
  Compare old vs new income-tax regime for a salaried individual in India (FY 2025-26)
  and recommend one. Use whenever a regime must be chosen or explained.
---

# Regime comparison

1. Gross income = salary + ALL other income (interest from AIS included).
2. Old-regime deductions are capped: 80C max 150000, 80D max 25000. Drop anything above the cap.
3. Call `calculate_tax` once with regime="new" and once with regime="old". Never do the maths yourself.
4. Reply with this table, then one line of recommendation:

| | New | Old |
|---|---|---|
| Taxable income | | |
| Total tax (incl. 4% cess) | | |

5. If the difference is under 5000, also mention the new regime needs no investment proofs.
