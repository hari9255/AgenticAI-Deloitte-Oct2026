"""Shared building blocks for the A2A + LangGraph demo.

- get_llm():                 picks the chat model (OpenAI, Gemini, Anthropic, Ollama ...)
- LangGraphAgentExecutor:    the A2A "Agent Executor" that wraps ANY LangGraph agent
- build_agent_card():        the A2A "Agent Card" (what can this agent do?)
- serve():                   starts the A2A server (Starlette + JSON-RPC over HTTP)
"""

import os

import uvicorn
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langgraph.graph.state import CompiledStateGraph
from starlette.applications import Starlette

from a2a.helpers import (
    get_message_text,
    new_task_from_user_message,
    new_text_message,
    new_text_part,
)
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes
from a2a.server.tasks import InMemoryTaskStore, TaskUpdater
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentSkill,
    TaskState,
)

load_dotenv()


# --------------------------------------------------------------------------
# 1. LLM
# --------------------------------------------------------------------------
def get_llm():
    """Return a LangChain chat model.

    Set LLM_MODEL in .env, e.g.
        openai:gpt-4o-mini
        google_genai:gemini-2.5-flash
        anthropic:claude-sonnet-4-5
        ollama:llama3.1          (fully local, no API key)
    """
    model = os.getenv("LLM_MODEL", "openai:gpt-4o-mini")
    return init_chat_model(model, temperature=0)


# --------------------------------------------------------------------------
# 2. Agent Executor  (bridge: A2A request  <->  LangGraph agent)
# --------------------------------------------------------------------------
class LangGraphAgentExecutor(AgentExecutor):
    """Runs a LangGraph agent for every A2A request and reports progress
    through the A2A Task lifecycle:

        submitted -> working (one update per tool call) -> completed / failed
    """

    def __init__(self, graph: CompiledStateGraph, agent_name: str):
        self.graph = graph
        self.agent_name = agent_name

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        # 1) Get or create the A2A Task for this request
        task = context.current_task
        if task is None:
            task = new_task_from_user_message(context.message)
            await event_queue.enqueue_event(task)  # state = SUBMITTED

        updater = TaskUpdater(event_queue, task.id, task.context_id)
        query = get_message_text(context.message)
        print(f"[{self.agent_name}] task={task.id[:8]} received: {query!r}")

        await updater.update_status(
            TaskState.TASK_STATE_WORKING,
            message=new_text_message(f"{self.agent_name} is working on it..."),
        )

        # 2) Run the LangGraph agent.
        #    The A2A contextId is used as the LangGraph thread_id, so follow-up
        #    messages in the same conversation keep their memory.
        config = {"configurable": {"thread_id": task.context_id}}
        final_answer = ""
        try:
            async for update in self.graph.astream(
                {"messages": [("user", query)]}, config, stream_mode="updates"
            ):
                for node, data in update.items():
                    for msg in data.get("messages", []):
                        # Tool call requested by the LLM -> stream a status update
                        for call in getattr(msg, "tool_calls", None) or []:
                            await updater.update_status(
                                TaskState.TASK_STATE_WORKING,
                                message=new_text_message(
                                    f"Calling tool {call['name']}({call['args']})"
                                ),
                            )
                        # Final AI answer (no further tool calls)
                        if node == "model" and not getattr(msg, "tool_calls", None):
                            final_answer = msg.text if hasattr(msg, "text") else str(msg.content)
        except Exception as exc:  # report failures through the protocol
            await updater.update_status(
                TaskState.TASK_STATE_FAILED,
                message=new_text_message(f"{self.agent_name} failed: {exc}"),
            )
            raise

        # 3) Return the result as an A2A Artifact and close the task
        await updater.add_artifact(
            parts=[new_text_part(text=final_answer, media_type="text/plain")],
            name=f"{self.agent_name} result",
        )
        await updater.update_status(
            TaskState.TASK_STATE_COMPLETED,
            message=new_text_message("Done"),
        )
        print(f"[{self.agent_name}] task={task.id[:8]} completed")

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        if context.current_task:
            updater = TaskUpdater(
                event_queue, context.current_task.id, context.current_task.context_id
            )
            await updater.update_status(TaskState.TASK_STATE_CANCELED)


# --------------------------------------------------------------------------
# 3. Agent Card  (served at  http://host:port/.well-known/agent-card.json)
# --------------------------------------------------------------------------
def build_agent_card(
    name: str, description: str, url: str, skills: list[AgentSkill]
) -> AgentCard:
    return AgentCard(
        name=name,
        description=description,
        version="1.0.0",
        default_input_modes=["text/plain"],
        default_output_modes=["text/plain"],
        capabilities=AgentCapabilities(streaming=True),
        supported_interfaces=[
            AgentInterface(protocol_binding="JSONRPC", url=url, protocol_version="1.0")
        ],
        skills=skills,
    )


# --------------------------------------------------------------------------
# 4. A2A Server
# --------------------------------------------------------------------------
def build_app(card: AgentCard, executor: AgentExecutor) -> Starlette:
    handler = DefaultRequestHandler(
        agent_executor=executor,
        task_store=InMemoryTaskStore(),
        agent_card=card,
    )
    routes = []
    routes.extend(create_agent_card_routes(card))      # Discovery
    routes.extend(create_jsonrpc_routes(handler, "/"))  # Communication (JSON-RPC)
    return Starlette(routes=routes)


def serve(card: AgentCard, executor: AgentExecutor, host: str, port: int) -> None:
    print(f"Starting '{card.name}' A2A server on http://{host}:{port}")
    print(f"Agent card: http://{host}:{port}/.well-known/agent-card.json")
    uvicorn.run(build_app(card, executor), host=host, port=port, log_level="warning")
